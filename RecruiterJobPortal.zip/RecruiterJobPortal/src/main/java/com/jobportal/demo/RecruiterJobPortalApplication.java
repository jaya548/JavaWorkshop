package com.jobportal.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecruiterJobPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecruiterJobPortalApplication.class, args);
	}

}
