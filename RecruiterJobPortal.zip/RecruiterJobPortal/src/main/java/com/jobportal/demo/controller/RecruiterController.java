package com.jobportal.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jobportal.demo.entity.Recruiter;
import com.jobportal.demo.service.RecruiterService;

@RestController
public class RecruiterController {
	
	@Autowired
	RecruiterService service;
	
	@PostMapping("/saveRecruiter")
	public String insertRecruiter(@RequestBody Recruiter rc) {
		service.saveRecruiter(rc);
		return "Recruiter saved successfully";
	}
	

}
