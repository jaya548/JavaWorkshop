package com.example.demo.repository;

import org.springframework.beans.factory.annotation.Autowired;

public class LoginService {

	@Autowired
	LoginRepositoty loginRepo;
	
}
	